#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

// Credentials structure to store username and password
typedef struct Credentials {
    char* username;
    char* password;
    int auth_flag;  // Adjacent memory to demonstrate overflow impact
} Credentials;

// Function to execute shell
void shell() {
    printf("Access granted! Executing /bin/sh...\n");
    system("/bin/sh");  // Execute /bin/sh to launch a shell
}

// Function with heap-based buffer overflow vulnerability
void authenticate() {
    Credentials* creds = (Credentials*)malloc(sizeof(Credentials));
    if (creds == NULL) {
        printf("Memory allocation failed!\n");
        exit(1);
    }

    // Allocate small buffers on the heap (vulnerable to overflow)
    creds->username = (char*)malloc(8);  // Intentionally small buffer
    creds->password = (char*)malloc(8);  // Intentionally small buffer
    creds->auth_flag = 0;               // Initialize flag to 0 (unauthenticated)

    if (creds->username == NULL || creds->password == NULL) {
        printf("Memory allocation failed for buffers!\n");
        free(creds->username);
        free(creds->password);
        free(creds);
        exit(1);
    }

    // Prompt for credentials
    char input[100];  // Large input buffer to allow overflow
    printf("Enter admin username: ");
    scanf("%99s", input);
    strcpy(creds->username, input);  // Vulnerability: No bounds checking, heap overflow possible

    printf("Enter admin password: ");
    scanf("%99s", input);
    strcpy(creds->password, input);  // Vulnerability: No bounds checking, heap overflow possible

    // Check credentials
    if (strcmp(creds->username, "admin") == 0 && strcmp(creds->password, "secret123") == 0) {
        creds->auth_flag = 1;  // Set flag to authenticated
    }

    // Check auth_flag (could be overwritten by buffer overflow)
    if (creds->auth_flag == 1) {
        shell();
    } else {
        printf("Authentication failed. Exiting...\n");
    }

    // Clean up
    free(creds->username);
    free(creds->password);
    free(creds);
}

int main() {
    printf("Admin Authentication System\n");
    authenticate();  // Call authenticate function
    return 0;
}