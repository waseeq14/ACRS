#include <klee/klee.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char* description;
    int priority;
} Task;

Task* create_task(const char* desc, int priority) {
    Task* task = (Task*)malloc(sizeof(Task));
    if (task == NULL) {
        return NULL;
    }
    task->description = (char*)malloc(strlen(desc) + 1);
    if (task->description == NULL) {
        free(task);
        return NULL;
    }
    strcpy(task->description, desc);
    task->priority = priority;
    return task;
}

int main() {
    char desc[100];
    int priority;
    klee_make_symbolic(desc, sizeof(desc), "desc");
    klee_make_symbolic(&priority, sizeof(priority), "priority");
    Task* task = create_task(desc, priority);
    klee_print_expr("Task pointer: ", task);
    return 0;
}