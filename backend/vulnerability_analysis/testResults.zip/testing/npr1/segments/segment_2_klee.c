#include <klee/klee.h>

typedef struct {
    char description[100];
    int priority;
} Task;

void process_task(Task* task) {
    klee_print_expr("Processing task with priority", task->priority);
    if (task->priority > 5) {
        klee_print_expr("High priority task detected", task->priority);
    }
}

int main() {
    Task task;
    klee_make_symbolic(&task.description, sizeof(task.description), "task_description");
    klee_make_symbolic(&task.priority, sizeof(task.priority), "task_priority");
    process_task(&task);
    return 0;
}