#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Task structure to represent a task with description and priority
typedef struct Task {
    char* description;
    int priority;
} Task;

// Function to create a task
Task* create_task(const char* desc, int priority) {
    Task* task = (Task*)malloc(sizeof(Task));
    if (task == NULL) {
        printf("Failed to allocate memory for task\n");
        return NULL;  // Simulating allocation failure for some cases
    }
    task->description = (char*)malloc(strlen(desc) + 1);
    if (task->description == NULL) {
        printf("Failed to allocate memory for description\n");
        free(task);
        return NULL;
    }
    strcpy(task->description, desc);
    task->priority = priority;
    return task;
}

// Function with null pointer dereference vulnerability
void process_task(Task* task) {
    // Vulnerability: No check for NULL before dereferencing
    printf("Processing task: %s with priority %d\n", task->description, task->priority);
    if (task->priority > 5) {  // Accessing task->priority without NULL check
        printf("High priority task detected!\n");
    }
}

// Function to display task details
void display_task(Task* task) {
    if (task == NULL) {
        printf("No task to display\n");
        return;
    }
    printf("Task: %s, Priority: %d\n", task->description, task->priority);
}

int main() {
    // Create a valid task
    Task* task1 = create_task("Complete report", 3);
    if (task1 == NULL) {
        printf("Failed to create task1\n");
        return 1;
    }

    // Create a task that might be NULL (simulating failure)
    Task* task2 = create_task("Review code", 7);  // May return NULL if allocation fails

    // Call functions
    display_task(task1);    // Safe call
    process_task(task2);    // Potential null pointer dereference
    display_task(task2);    // Safe due to NULL check

    // Clean up
    if (task1 != NULL) {
        free(task1->description);
        free(task1);
    }
    if (task2 != NULL) {  // Proper cleanup, but process_task already risked dereference
        free(task2->description);
        free(task2);
    }

    return 0;
}