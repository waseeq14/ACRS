#include <klee/klee.h>
#include <string.h>
#include <unistd.h>

typedef struct {
    char username[16];
    unsigned int password;
} Credentials;

void verify_password(Credentials *cred) {
    unsigned int check = 0x7FFFFFFF;
    check = check + cred->password;
    if (strcmp(cred->username, "admin") == 0 && (int)check < 0) {
        char *args[] = {"/bin/sh", NULL};
        execve("/bin/sh", args, NULL);
    }
}

int main() {
    Credentials cred;
    klee_make_symbolic(&cred.username, sizeof(cred.username), "username");
    klee_make_symbolic(&cred.password, sizeof(cred.password), "password");
    verify_password(&cred);
    return 0;
}