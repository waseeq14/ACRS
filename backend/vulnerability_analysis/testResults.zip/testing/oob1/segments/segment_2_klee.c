#include <klee/klee.h>
#include <string.h>

typedef struct Employee {
    int id;
    char name[10];
    struct Employee* next;
} Employee;

void update_employee(Employee* head, int id) {
    Employee* current = head;
    while (current != NULL && current->id != id) {
        current = current->next;
    }

    if (current == NULL) {
        klee_print_expr("Employee ID not found", id);
        return;
    }

    char buffer[100];
    klee_make_symbolic(buffer, sizeof(buffer), "buffer");

    for (int i = 0; i < strlen(buffer); i++) {
        current->name[i] = buffer[i];
    }
    current->name[strlen(buffer)] = '\0';
    klee_print_expr("Employee ID updated", id);
}

int main() {
    Employee e1, e2;
    e1.id = 1;
    e2.id = 2;
    e1.next = &e2;
    e2.next = NULL;

    int id;
    klee_make_symbolic(&id, sizeof(id), "id");

    update_employee(&e1, id);

    return 0;
}