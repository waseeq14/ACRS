#include <klee/klee.h>
#include <stdlib.h>
#include <string.h>

typedef struct Employee {
    int id;
    char* name;
    struct Employee* next;
} Employee;

Employee* create_employee(Employee* head, int id) {
    char buffer[100];
    klee_make_symbolic(buffer, sizeof(buffer), "buffer");

    Employee* new_employee = (Employee*)malloc(sizeof(Employee));
    if (new_employee == NULL) {
        return head;
    }

    new_employee->id = id;
    new_employee->name = (char*)malloc(10);
    if (new_employee->name == NULL) {
        free(new_employee);
        return head;
    }
    strncpy(new_employee->name, buffer, 10);
    new_employee->name[9] = '\0';
    new_employee->next = head;

    return new_employee;
}

int main() {
    Employee* head = NULL;
    int id;
    klee_make_symbolic(&id, sizeof(id), "id");
    head = create_employee(head, id);
    return 0;
}