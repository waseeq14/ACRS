#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Employee structure for linked list
typedef struct Employee {
    int id;
    char* name;  // Dynamically allocated name
    struct Employee* next;
} Employee;

// Function to create a new employee and add to the list
Employee* create_employee(Employee* head, int id) {
    char buffer[100];
    printf("Enter name for employee ID %d: ", id);
    scanf("%99s", buffer);

    Employee* new_employee = (Employee*)malloc(sizeof(Employee));
    if (new_employee == NULL) {
        printf("Memory allocation failed for employee\n");
        return head;
    }

    new_employee->id = id;
    new_employee->name = (char*)malloc(10);  // Fixed size for name (vulnerable to overflow)
    if (new_employee->name == NULL) {
        printf("Memory allocation failed for name\n");
        free(new_employee);
        return head;
    }
    strncpy(new_employee->name, buffer, 10);  // Safe copy for creation
    new_employee->name[9] = '\0';  // Ensure null termination
    new_employee->next = head;

    printf("Employee ID %d created\n", id);
    return new_employee;
}

// Function with out-of-bounds pointer vulnerability
void update_employee(Employee* head, int id) {
    Employee* current = head;
    while (current != NULL && current->id != id) {
        current = current->next;
    }

    if (current == NULL) {
        printf("Employee ID %d not found\n", id);
        return;
    }

    char buffer[100];
    printf("Enter new name for employee ID %d: ", id);
    scanf("%99s", buffer);

    // Vulnerability: Writing beyond allocated name buffer (10 bytes)
    for (int i = 0; i < strlen(buffer); i++) {
        current->name[i] = buffer[i];  // Out-of-bounds write if buffer > 9 bytes
    }
    current->name[strlen(buffer)] = '\0';  // Out-of-bounds write for null terminator
    printf("Employee ID %d updated\n", id);
}

// Function to count employees in the list
int count_employees(Employee* head) {
    int count = 0;
    Employee* current = head;
    while (current != NULL) {
        count++;
        current = current->next;
    }
    printf("Total employees: %d\n", count);
    return count;
}

// Function to print all employees
void print_employees(Employee* head) {
    Employee* current = head;
    if (current == NULL) {
        printf("No employees to display\n");
        return;
    }

    printf("Employee List:\n");
    while (current != NULL) {
        printf("ID: %d, Name: %s\n", current->id, current->name);
        current = current->next;
    }
}

// Function to free the linked list
void free_list(Employee* head) {
    Employee* current = head;
    while (current != NULL) {
        Employee* temp = current;
        current = current->next;
        free(temp->name);
        free(temp);
    }
    printf("Employee list freed\n");
}

int main() {
    printf("Employee Database System\n");
    Employee* head = NULL;

    // Call functions in sequence
    head = create_employee(head, 1);  // Create employee with ID 1
    head = create_employee(head, 2);  // Create employee with ID 2
    update_employee(head, 1);         // Vulnerable to out-of-bounds write
    count_employees(head);            // Count employees
    print_employees(head);            // Display all employees
    free_list(head);                  // Clean up memory

    return 0;
}