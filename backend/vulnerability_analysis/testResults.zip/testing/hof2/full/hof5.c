#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

// Maximum input size for user input
#define MAX_INPUT 100
// Pre-stored password and its hash
#define SECRET_PASSWORD "secret123"
#define SECRET_HASH 1596  // Precomputed hash for "secret123"

// Credentials structure to store password and hash
typedef struct {
    char* password;  // Dynamically allocated password
    uint32_t hash;   // Computed hash
    int auth_flag;   // Authentication flag (vulnerable to overwrite)
} Credentials;

// Function to compute a simple hash of the input string
uint32_t compute_hash(const char* input) {
    uint32_t hash = 0;
    for (int i = 0; input[i] != '\0'; i++) {
        hash += (uint32_t)(input[i] * (i + 1));  // Simple hash: ASCII * position
    }
    return hash;
}

// Function to get user input
void get_input(Credentials* cred) {
    char buffer[MAX_INPUT];
    printf("Enter password to authenticate: ");
    if (fgets(buffer, MAX_INPUT, stdin) == NULL) {
        printf("Error reading input\n");
        exit(1);
    }
    buffer[strcspn(buffer, "\n")] = '\0';  // Remove newline

    cred->password = (char*)malloc(MAX_INPUT);
    if (cred->password == NULL) {
        printf("Memory allocation failed for password\n");
        exit(1);
    }
    strncpy(cred->password, buffer, MAX_INPUT - 1);
    cred->password[MAX_INPUT - 1] = '\0';
}

// Function with heap-based buffer overflow vulnerability
void hash_input(Credentials* cred) {
    char* temp_buffer = (char*)malloc(10);  // Small heap buffer (vulnerable)
    if (temp_buffer == NULL) {
        printf("Memory allocation failed for temp buffer\n");
        exit(1);
    }

    // Vulnerability: Copying input to small buffer without bounds checking
    strcpy(temp_buffer, cred->password);  // Heap overflow if password > 9 bytes
    cred->hash = compute_hash(temp_buffer);  // Compute hash from temp buffer
    cred->auth_flag = 0;  // Initialize auth flag

    free(temp_buffer);  // Clean up temp buffer
}

// Function to compare computed hash with pre-stored hash
void compare_hashes(Credentials* cred) {
    uint32_t stored_hash = SECRET_HASH;  // Precomputed hash of "secret123"
    if (cred->hash == stored_hash) {
        cred->auth_flag = 1;  // Set flag if hashes match
    } else {
        cred->auth_flag = 0;  // Reset flag if hashes don't match
    }
}

// Function to authenticate based on auth_flag
void authenticate(Credentials* cred) {
    if (cred->auth_flag == 1) {
        printf("Authentication successful! Access granted.\n");
    } else {
        printf("Authentication failed. Access denied.\n");
    }
}

// Function to display authentication result
void display_result(Credentials* cred) {
    printf("Input Password: %s\n", cred->password);
    printf("Computed Hash: %u\n", cred->hash);
    printf("Stored Hash: %u\n", SECRET_HASH);
    if (cred->auth_flag == 1) {
        printf("Status: Authenticated\n");
    } else {
        printf("Status: Not Authenticated\n");
    }
}

// Function to clean up allocated memory
void cleanup(Credentials* cred) {
    if (cred->password != NULL) {
        free(cred->password);
        cred->password = NULL;
    }
}

int main() {
    printf("Password Authentication System\n");
    printf("================================\n");
    printf("Enter the correct password to gain access.\n");
    printf("Hint: The secret password is hashed to %u\n", SECRET_HASH);
    printf("================================\n");

    Credentials cred = {NULL, 0, 0};  // Initialize credentials

    // Call functions in sequence
    get_input(&cred);         // Get user input
    hash_input(&cred);        // Compute hash (heap overflow vulnerability)
    compare_hashes(&cred);    // Compare hashes
    authenticate(&cred);       // Authenticate based on flag
    display_result(&cred);     // Display results
    cleanup(&cred);           // Clean up memory

    return 0;
}