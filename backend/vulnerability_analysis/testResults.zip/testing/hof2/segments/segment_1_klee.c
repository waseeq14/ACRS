#include <klee/klee.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    char* password;
    int hash;
    int auth_flag;
} Credentials;

int compute_hash(const char* input);

void hash_input(Credentials* cred) {
    char* temp_buffer = (char*)malloc(10);
    if (temp_buffer == NULL) {
        exit(1);
    }
    strcpy(temp_buffer, cred->password);
    cred->hash = compute_hash(temp_buffer);
    cred->auth_flag = 0;
    free(temp_buffer);
}

int main() {
    Credentials cred;
    char password[20];
    klee_make_symbolic(password, sizeof(password), "password");
    cred.password = password;
    hash_input(&cred);
    klee_print_expr("Hash:", cred.hash);
    klee_print_expr("Auth Flag:", cred.auth_flag);
    return 0;
}