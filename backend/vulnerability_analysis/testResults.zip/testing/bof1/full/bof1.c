#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Task structure to store ID and description
typedef struct Task {
    int id;
    char* description;
} Task;

// Function to input task details
void input_task(Task* task) {
    char buffer[100];
    printf("Enter task ID: ");
    scanf("%d", &task->id);
    printf("Enter task description: ");
    scanf("%99s", buffer);  // Safe input with limit
    task->description = (char*)malloc(strlen(buffer) + 1);
    if (task->description == NULL) {
        printf("Memory allocation failed!\n");
        exit(1);
    }
    strcpy(task->description, buffer);
}

// Function with stack-based buffer overflow vulnerability
void process_task(Task* task) {
    char temp[10];  // Small fixed-size buffer, vulnerable to overflow
    // Vulnerability: No bounds checking when copying description
    strcpy(temp, task->description);  // Buffer overflow if description > 9 bytes
    printf("Processing task ID %d: %s\n", task->id, temp);
}

// Function to store task (simulated)
void store_task(Task* task) {
    printf("Storing task ID %d with description: %s\n", task->id, task->description);
}

// Function to validate task
void validate_task(Task* task) {
    if (task->id < 0) {
        printf("Invalid task ID: %d\n", task->id);
    } else {
        printf("Task ID %d is valid\n", task->id);
    }
}

// Function to display task details
void display_task(Task* task) {
    printf("Task Details: ID = %d, Description = %s\n", task->id, task->description);
}

int main() {
    printf("Task Management System\n");
    
    Task task = {0, NULL};  // Initialize task
    
    // Call functions in sequence
    input_task(&task);      // Get user input
    process_task(&task);    // Vulnerable to buffer overflow
    store_task(&task);      // Store task
    validate_task(&task);   // Validate task
    display_task(&task);    // Display task
    
    // Clean up
    if (task.description != NULL) {
        free(task.description);
    }
    
    return 0;
}