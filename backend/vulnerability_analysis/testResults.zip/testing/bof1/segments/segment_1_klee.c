#include <klee/klee.h>
#include <string.h>

typedef struct {
    int id;
    char description[10];
} Task;

void process_task(Task* task) {
    char temp[10];
    strcpy(temp, task->description);
    klee_print_expr("Processing task ID", task->id);
}

int main() {
    Task task;
    klee_make_symbolic(&task.id, sizeof(task.id), "task_id");
    klee_make_symbolic(task.description, sizeof(task.description), "task_description");
    process_task(&task);
    return 0;
}