#include <klee/klee.h>

int main() {
    int a, b, c;
    klee_make_symbolic(&a, sizeof(a), "a");
    klee_make_symbolic(&b, sizeof(b), "b");
    klee_make_symbolic(&c, sizeof(c), "c");

    if (a > b) {
        c = a - b;
    } else {
        c = b - a;
    }

    klee_print_expr("c: ", c);

    return 0;
}