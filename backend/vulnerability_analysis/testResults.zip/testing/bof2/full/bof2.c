#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function to display encrypted data
void display_encrypted(char* encrypted, int len) {
    printf("Encrypted data: ");
    for (int i = 0; i < len; i++) {
        printf("%02x ", (unsigned char)encrypted[i]);  // Display as hex
    }
    printf("\n");
}

// Function to obfuscate (encrypt) data with a key
void obfuscate(char* data, char* key, char* output) {
    int data_len = strlen(data);
    int key_len = strlen(key);
    
    // Vulnerability: Fixed-size buffer (10 bytes) for output, no bounds checking
    char temp[10];  // Intentionally small buffer
    strcpy(temp, data);  // Buffer overflow if data > 9 bytes (plus null terminator)

    // Simple XOR encryption
    for (int i = 0; i < data_len; i++) {
        output[i] = temp[i] ^ key[i % key_len];  // XOR with key (repeating key if needed)
    }
}

// Function to handle input and call obfuscation
void input_data() {
    char data[100];  // Large input buffer
    char key[100];   // Large key buffer
    char* output = (char*)malloc(100);  // Output buffer for encrypted data
    if (output == NULL) {
        printf("Memory allocation failed!\n");
        exit(1);
    }

    // Get user input
    printf("Enter data to encrypt: ");
    scanf("%99s", data);
    printf("Enter encryption key: ");
    scanf("%99s", key);

    // Call obfuscate with input data and key
    obfuscate(data, key, output);

    // Display encrypted result
    display_encrypted(output, strlen(data));

    // Clean up
    free(output);
}

int main() {
    printf("Simple Encryption Program\n");
    input_data();  // Call input function to start process
    return 0;
}