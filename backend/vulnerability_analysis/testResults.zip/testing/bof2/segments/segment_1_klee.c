#include <klee/klee.h>
#include <string.h>

void obfuscate(char* data, char* key, char* output) {
    int data_len = strlen(data);
    int key_len = strlen(key);
    char temp[10];
    strcpy(temp, data);
    for (int i = 0; i < data_len; i++) {
        output[i] = temp[i] ^ key[i % key_len];
    }
}

int main() {
    char data[10];
    char key[10];
    char output[10];
    klee_make_symbolic(data, sizeof(data), "data");
    klee_make_symbolic(key, sizeof(key), "key");
    klee_make_symbolic(output, sizeof(output), "output");
    obfuscate(data, key, output);
    return 0;
}