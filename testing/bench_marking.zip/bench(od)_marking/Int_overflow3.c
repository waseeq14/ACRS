#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define MAX_INPUT 100
#define MAX_USERNAME 50

typedef struct {
    char username[MAX_USERNAME];
    int password;
} Credentials;

void display_credentials(Credentials *cred) {
    printf("Credentials - Username: %s, Password: %d\n", cred->username, cred->password);
}

void verify_password(Credentials *cred) {
    unsigned int check = 0x7FFFFFFF; // Near max for 32-bit int
    check = check + cred->password; // Integer overflow: can wrap to negative if password is large
    if (strcmp(cred->username, "admin") == 0 && (int)check < 0) {
        printf("Admin access granted, launching shell...\n");
        char *args[] = {"/bin/sh", NULL};
        execve("/bin/sh", args, NULL);
    } else {
        printf("Verification failed.\n");
    }
}

int main() {
    Credentials cred = {{0}, 0};
    int choice;
    char buffer[MAX_INPUT];
    char input[MAX_INPUT];

    while (1) {
        printf("\nLogin System Menu:\n1. Enter Credentials\n2. Verify Password\n3. Display Credentials\n4. Exit\n");
        printf("Enter choice: ");
        fgets(buffer, MAX_INPUT, stdin);
        sscanf(buffer, "%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter username: ");
                fgets(input, MAX_INPUT, stdin);
                input[strcspn(input, "\n")] = '\0';
                strncpy(cred.username, input, MAX_USERNAME - 1);
                cred.username[MAX_USERNAME - 1] = '\0';
                
                printf("Enter password (integer): ");
                fgets(input, MAX_INPUT, stdin);
                sscanf(input, "%d", &cred.password);
                printf("Credentials entered.\n");
                break;
            case 2:
                if (cred.username[0] != '\0') {
                    verify_password(&cred);
                } else {
                    printf("No credentials entered yet.\n");
                }
                break;
            case 3:
                if (cred.username[0] != '\0') {
                    display_credentials(&cred);
                } else {
                    printf("No credentials entered yet.\n");
                }
                break;
            case 4:
                printf("Exiting.\n");
                return 0;
            default:
                printf("Invalid choice.\n");
        }
    }
}